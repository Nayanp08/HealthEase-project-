// script.js

const container = document.querySelector('.container');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');

let currentIndex = 0;

prevBtn.addEventListener('click', () => {
  if (currentIndex > 0) {
    currentIndex--;
    updateImage();
  }
});

nextBtn.addEventListener('click', () => {
  // Replace the condition below with the total number of images in your gallery.
  if (currentIndex < totalImages - 1) {
    currentIndex++;
    updateImage();
  }
});

function updateImage() {
  const imageInfo = document.querySelector('.image-info');
  const offset = -currentIndex * 100; // Assuming each image is 100% wide

  imageInfo.style.transform = `translateX(${offset}%)`;
}
